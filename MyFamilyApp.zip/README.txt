My Family App - Android project (upload this ZIP to GitHub as it is, do NOT unzip it)
See the steps in the chat message.
